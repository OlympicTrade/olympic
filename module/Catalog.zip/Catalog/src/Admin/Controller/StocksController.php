<?php
namespace CatalogAdmin\Controller;

use Aptero\Mvc\Controller\Admin\AbstractActionController;

class StocksController extends AbstractActionController
{
    public function indexAction() {
        $this->generate();

        $diff = $this->getServiceLocator()->get('CatalogAdmin\Service\StocksService')->findDifference();

        return ['diffs' => $diff];
    }
}