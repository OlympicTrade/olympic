<?php
namespace CatalogAdmin\Form\Element;

use Zend\Form\Element;

class ProductProps extends Element
{
    protected $attributes = array(
        'type' => 'filemanager',
    );
}
