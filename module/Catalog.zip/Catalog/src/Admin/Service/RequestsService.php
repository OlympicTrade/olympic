<?php
namespace CatalogAdmin\Service;

use Aptero\Service\Admin\TableService;

class RequestsService extends TableService
{

}