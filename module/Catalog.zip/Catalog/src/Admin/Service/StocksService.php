<?php
namespace CatalogAdmin\Service;

use Aptero\Service\AbstractService;
use Catalog\Model\Product;
use CatalogAdmin\Model\Products;
use Zend\Json\Json;

class StocksService extends AbstractService
{
    const SITE = 'http://myprotein';

    public function findDifference()
    {
        $diff = [];
        $otDomain = 'https://' . $_SERVER["HTTP_HOST"];

        $products = Products::getEntityCollection();
        $products->select()
            ->columns(['id', 'name'])
            ->limit(3)
            ->where
                ->equalTo('sync_id', 0);

        $diff['products'] = [];
        foreach ($products as $product) {
            $diff['products'][] = [
                'name' => $product->get('name'),
                'url'  => $otDomain . '/admin/catalog/products/edit/?id=' . $product->getId(),
            ];
        }

        $products = Products::getEntityCollection();
        $products->select()
            ->columns(['id', 'sync_id', 'name'])
            ->limit(3)
            ->where
                //->equalTo('id', 7)
                ->notEqualTo('sync_id', 0);

        foreach ($products as $product) {
            $pDiff = [
                'name'  => $product->get('name'),
                'ot_url'  => $otDomain . '/admin/catalog/products/edit/?id=' . $product->getId(),
                'mp_url'  => self::SITE . '/admin/catalog/products/edit/?id=' . $product->get('sync_id'),
            ];

            $data = file_get_contents(self::SITE . '/sync/stock/product/?id=' . $product->get('sync_id'));

            try {
                $data = Json::decode($data);
            } catch (\Exception $e) {
                die(self::SITE . '/sync/stock/product/?id=' . $product->get('sync_id'));
            }

            $exclude['size'] = [];
            $all['size'] = [];
            $pDiff['size'] = [];
            foreach ($data->size as $mpSize) {
                $result = $this->checkSizes($product, $mpSize);
                $all['size'][] = $mpSize->name;
                if(!$result) {
                    $exclude['size'][] = $mpSize->name;
                    $pDiff['size'][] = $mpSize->name;
                }
            }

            $select = $this->getSql()->select();
            $select->from(['t' => 'products_size'])
                ->columns(['name'])
                ->where
                    ->equalTo('depend', $product->getId())
                    ->notIn('name', $all['size']);
            foreach ($this->execute($select) as $row) {
                $pDiff['size'][] = $row['name'];
            }

            $exclude['taste'] = [];
            $all['taste'] = [];
            $pDiff['taste'] = [];
            foreach ($data->price as $mpTaste) {
                $result = $this->checkTaste($product, $mpTaste);
                $all['taste'][] = $mpTaste->name;
                if(!$result) {
                    $exclude['taste'][] = $mpTaste->name;
                    $pDiff['taste'][] = $mpTaste->name;
                }
            }

            $select = $this->getSql()->select();
            $select->from(['t' => 'products_taste'])
                ->columns(['name'])
                ->where
                ->equalTo('depend', $product->getId())
                ->notIn('name', $all['taste']);
            foreach ($this->execute($select) as $row) {
                $pDiff['taste'][] = $row['name'];
            }

            $pDiff['stock'] = [];
            foreach ($data->stock as $stockPos) {
                if(in_array($stockPos->price, $exclude['taste']) || in_array($stockPos->size, $exclude['size'])) {
                    continue;
                }

                $result = $this->checkStock($product, $stockPos);
                if(!$result['status']) {
                    $pDiff['stock'][] = $result;
                }
            }

            if($pDiff['size'] || $pDiff['taste'] || $pDiff['stock']) {
                $diff[] = $pDiff;
            }
        }

        return $diff;
    }

    public function checkStock(Products $product, $mpData)
    {
        $select = $this->getSql()->select();
        $select->from(['p' => 'products_stock'])
            ->columns(['count'])
            ->join(['ps' => 'products_size'], 'ps.id = p.size_id', [])
            ->join(['pt' => 'products_taste'], 'pt.id = p.taste_id', [])
            ->where([
                'p.product_id' => $product->getId(),
                'ps.name' => $mpData->size,
                'pt.name' => $mpData->price,
            ]);

        $row = $this->execute($select)->current();
        if($row === false) {
            die($this->getSql()->buildSqlString($select));
            throw new \Exception('Can\'t find stock row');
        }

        $otCount = (int) $row['count'];
        $mpCount = (int) $mpData->count;

        if($otCount == $mpCount) {
            return ['status' => true];
        }

        return [
            'ot'     => $otCount,
            'mp'     => $mpCount,
            'size'   => $mpData->size,
            'taste'  => $mpData->price,
            'status' => false,
        ];
    }

    public function checkTaste(Products $product, $mpData)
    {
        $select = $this->getSql()->select();
        $select->from(['t' => 'products_taste'])
            ->columns(['id'])
            ->where([
                'depend' => $product->getId(),
                'name'   => $mpData->name
            ]);


        return (bool) $this->execute($select)->current();
    }

    public function checkSizes(Products $product, $mpData)
    {
        $select = $this->getSql()->select();
        $select->from(['t' => 'products_size'])
            ->columns(['id'])
            ->where([
                'depend' => $product->getId(),
                'name'   => $mpData->name
            ]);


        return (bool) $this->execute($select)->current();
    }
}