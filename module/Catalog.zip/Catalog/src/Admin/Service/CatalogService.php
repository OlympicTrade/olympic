<?php
namespace CatalogAdmin\Service;

use Aptero\Service\Admin\TableService;

class CatalogService extends TableService
{

}